export interface ErrorMessage {
  code: string | null
  title: string
  messageLines: string[]
}
